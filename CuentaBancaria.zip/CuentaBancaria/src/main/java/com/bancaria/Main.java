package com.bancaria;

import com.bancaria.exception.CuentaInvalidaException;
import com.bancaria.model.CuentaAhorros;
import com.bancaria.model.CuentaCorriente;
import com.bancaria.service.BancoService;
import com.bancaria.ui.ConsoleUI;

/**
 * Punto de entrada de la aplicación Cuenta Bancaria.
 *
 * Inicializa el banco con cuentas de demostración y lanza la interfaz de consola.
 */
public class Main {

    public static void main(String[] args) {

        // ── Inicialización del banco ──────────────────────────────────────────
        BancoService banco = new BancoService("Banco San Buenaventura");

        System.out.println("\n  Inicializando cuentas de demostración...\n");

        try {
            // Cuenta de Ahorros — titular 1
            CuentaAhorros ahorros1 = new CuentaAhorros(
                    "AH-001", "Diego García", 2_000_000.0, 0.04 // 4% mensual
            );
            banco.registrarCuenta(ahorros1);

            // Cuenta de Ahorros — titular 2
            CuentaAhorros ahorros2 = new CuentaAhorros(
                    "AH-002", "Laura Martínez", 500_000.0, 0.035 // 3.5% mensual
            );
            banco.registrarCuenta(ahorros2);

            // Cuenta Corriente — titular 1
            CuentaCorriente corriente1 = new CuentaCorriente(
                    "CC-001", "Diego García", 800_000.0, 500_000.0 // cupo sobregiro $500k
            );
            banco.registrarCuenta(corriente1);

            // Cuenta Corriente — empresa
            CuentaCorriente corriente2 = new CuentaCorriente(
                    "CC-002", "TechCorp S.A.S", 5_000_000.0, 2_000_000.0
            );
            banco.registrarCuenta(corriente2);

        } catch (CuentaInvalidaException | IllegalArgumentException e) {
            System.err.println("Error al inicializar cuentas: " + e.getMessage());
            return;
        }

        // ── Lanzar interfaz de usuario ────────────────────────────────────────
        ConsoleUI ui = new ConsoleUI(banco);
        ui.iniciar();
    }
}
