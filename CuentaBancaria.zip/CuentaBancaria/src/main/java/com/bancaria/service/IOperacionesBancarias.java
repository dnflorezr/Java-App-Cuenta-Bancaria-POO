package com.bancaria.service;

import com.bancaria.exception.MontoInvalidoException;
import com.bancaria.exception.SaldoInsuficienteException;

/**
 * Contrato que define las operaciones básicas de cualquier cuenta bancaria.
 * Principio: Inversión de Dependencias — los servicios dependen de esta abstracción,
 *            no de implementaciones concretas.
 * Principio: Abierto/Cerrado — se pueden agregar nuevas cuentas sin modificar los servicios.
 */
public interface IOperacionesBancarias {

    /**
     * Deposita un monto en la cuenta.
     * @param monto Valor a depositar (debe ser > 0)
     * @throws MontoInvalidoException si el monto no es válido
     */
    void depositar(double monto) throws MontoInvalidoException;

    /**
     * Retira un monto de la cuenta.
     * @param monto Valor a retirar (debe ser > 0)
     * @throws MontoInvalidoException     si el monto no es válido
     * @throws SaldoInsuficienteException si no hay fondos suficientes
     */
    void retirar(double monto) throws MontoInvalidoException, SaldoInsuficienteException;

    /**
     * Retorna el saldo actual disponible.
     */
    double getSaldo();

    /**
     * Retorna el número único de la cuenta.
     */
    String getNumeroCuenta();

    /**
     * Retorna el nombre del titular de la cuenta.
     */
    String getTitular();
}
