package com.bancaria.service;

import com.bancaria.exception.CuentaInvalidaException;
import com.bancaria.model.CuentaBancaria;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Fachada del sistema bancario: registro central de cuentas activas.
 * Permite buscar, listar y validar cuentas registradas.
 *
 * FUNCIONALIDAD 3 (soporte): Gestión centralizada de cuentas del banco
 *
 * Principio: Responsabilidad Única — solo gestiona el registro de cuentas.
 * Principio: Encapsulación — el mapa interno no se expone directamente.
 */
public class BancoService {

    private final String nombreBanco;
    private final Map<String, CuentaBancaria> cuentas;

    public BancoService(String nombreBanco) {
        this.nombreBanco = nombreBanco;
        this.cuentas = new LinkedHashMap<>();
    }

    // ── Registro y consulta ──────────────────────────────────────────────────

    /**
     * Registra una nueva cuenta en el sistema.
     * @throws CuentaInvalidaException si ya existe una cuenta con ese número
     */
    public void registrarCuenta(CuentaBancaria cuenta) throws CuentaInvalidaException {
        if (cuenta == null)
            throw new CuentaInvalidaException("No se puede registrar una cuenta nula.");
        String num = cuenta.getNumeroCuenta();
        if (cuentas.containsKey(num))
            throw new CuentaInvalidaException(num, "ya existe en el sistema");
        cuentas.put(num, cuenta);
        System.out.printf("  ✔ Cuenta registrada: [%s] — %s (%s)%n",
                num, cuenta.getTitular(), cuenta.getTipoCuenta());
    }

    /**
     * Busca una cuenta por número.
     * @throws CuentaInvalidaException si la cuenta no existe
     */
    public CuentaBancaria buscarCuenta(String numeroCuenta) throws CuentaInvalidaException {
        if (numeroCuenta == null || numeroCuenta.isBlank())
            throw new CuentaInvalidaException("El número de cuenta no puede estar vacío.");
        CuentaBancaria cuenta = cuentas.get(numeroCuenta.trim().toUpperCase());
        if (cuenta == null)
            throw new CuentaInvalidaException(numeroCuenta, "no encontrada en el sistema");
        return cuenta;
    }

    /**
     * Retorna todas las cuentas registradas (vista inmutable).
     */
    public Collection<CuentaBancaria> listarCuentas() {
        return Collections.unmodifiableCollection(cuentas.values());
    }

    public String getNombreBanco() { return nombreBanco; }

    public int totalCuentas()     { return cuentas.size(); }

    /**
     * Imprime un resumen de todas las cuentas registradas.
     */
    public void imprimirResumen() {
        System.out.printf("%n  ╔══ %s — %d cuenta(s) ══╗%n", nombreBanco, cuentas.size());
        if (cuentas.isEmpty()) {
            System.out.println("  No hay cuentas registradas.");
        } else {
            cuentas.values().forEach(c ->
                System.out.printf("  │  [%-10s] %-25s (%s) — Saldo: $%,.2f%n",
                        c.getNumeroCuenta(), c.getTitular(),
                        c.getTipoCuenta(), c.getSaldo())
            );
        }
        System.out.println("  ╚══════════════════════════════════════╝");
    }
}
