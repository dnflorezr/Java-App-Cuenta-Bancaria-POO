package com.bancaria.service;

import com.bancaria.exception.MontoInvalidoException;
import com.bancaria.model.CuentaAhorros;
import com.bancaria.model.CuentaCorriente;
import com.bancaria.model.Transaccion;
import com.bancaria.model.TipoTransaccion;

/**
 * Servicio que aplica intereses a Cuentas de Ahorros y
 * cargos de mantenimiento a Cuentas Corrientes.
 *
 * FUNCIONALIDAD 2: Aplicación de intereses y cargos
 *
 * Principio: Responsabilidad Única — solo calcula y aplica intereses/cargos.
 * Principio: Abierto/Cerrado — nuevos tipos de cargo se agregan sin modificar esta clase.
 */
public class InteresCargoService {

    private static final double CARGO_SOBREGIRO = 25_000.0; // COP por mes en sobregiro

    /**
     * Aplica interés mensual a una Cuenta de Ahorros usando interés compuesto.
     * Fórmula: Saldo_nuevo = Saldo_actual × (1 + tasa)
     *
     * @param cuenta Cuenta de ahorros a la que se aplica el interés
     */
    public void aplicarInteresMensual(CuentaAhorros cuenta) {
        double saldoAnterior = cuenta.getSaldo();
        double interes = saldoAnterior * cuenta.getTasaInteres();

        cuenta.acreditarInteres(interes);
        cuenta.incrementarPeriodo();

        cuenta.getHistorial().registrar(new Transaccion(
                cuenta.getHistorial().generarId(),
                TipoTransaccion.APLICACION_INTERES,
                interes,
                saldoAnterior,
                cuenta.getSaldo(),
                String.format("Interés mensual (%.2f%%) — Periodo #%d",
                        cuenta.getTasaInteres() * 100,
                        cuenta.getPeriodosMes()),
                cuenta.getNumeroCuenta()
        ));

        System.out.printf("%n  ✔ Interés aplicado: +$%,.2f (%.2f%%)  |  Nuevo saldo: $%,.2f%n",
                interes, cuenta.getTasaInteres() * 100, cuenta.getSaldo());
    }

    /**
     * Aplica cargo de mantenimiento mensual a una Cuenta Corriente.
     * Si el saldo es insuficiente, el cargo lleva el saldo a negativo (sobregiro).
     *
     * @param cuenta Cuenta corriente a la que se aplica el cargo
     */
    public void aplicarCargoMantenimiento(CuentaCorriente cuenta) {
        double cargo = cuenta.getCargoMantenimiento();
        double saldoAnterior = cuenta.getSaldo();
        double saldoDisponible = saldoAnterior + cuenta.getCupoSobregiro();

        if (cargo > saldoDisponible) {
            System.out.printf("%n  ✖ Saldo insuficiente para cargo de mantenimiento ($%,.2f).%n", cargo);
            return;
        }

        cuenta.aplicarCargo(cargo);

        if (cuenta.getSaldo() < 0) {
            cuenta.setSobregiroActivo(true);
        }

        cuenta.getHistorial().registrar(new Transaccion(
                cuenta.getHistorial().generarId(),
                TipoTransaccion.CARGO_MANTENIMIENTO,
                cargo,
                saldoAnterior,
                cuenta.getSaldo(),
                "Cargo mensual de mantenimiento",
                cuenta.getNumeroCuenta()
        ));

        System.out.printf("%n  ✔ Cargo de mantenimiento aplicado: -$%,.2f  |  Nuevo saldo: $%,.2f%n",
                cargo, cuenta.getSaldo());
    }

    /**
     * Aplica cargo adicional por permanencia en sobregiro.
     *
     * @param cuenta Cuenta corriente en sobregiro
     */
    public void aplicarCargoSobregiro(CuentaCorriente cuenta) {
        if (!cuenta.isSobregiroActivo()) {
            System.out.println("  La cuenta no tiene sobregiro activo. No se aplica cargo.");
            return;
        }

        double saldoAnterior = cuenta.getSaldo();
        cuenta.aplicarCargo(CARGO_SOBREGIRO);

        cuenta.getHistorial().registrar(new Transaccion(
                cuenta.getHistorial().generarId(),
                TipoTransaccion.CARGO_SOBREGIRO,
                CARGO_SOBREGIRO,
                saldoAnterior,
                cuenta.getSaldo(),
                "Cargo por permanencia en sobregiro",
                cuenta.getNumeroCuenta()
        ));

        System.out.printf("%n  ✔ Cargo por sobregiro aplicado: -$%,.2f  |  Nuevo saldo: $%,.2f%n",
                CARGO_SOBREGIRO, cuenta.getSaldo());
    }

    /**
     * Proyecta el crecimiento de una Cuenta de Ahorros a N meses (sin modificar la cuenta).
     *
     * @param cuenta  Cuenta de ahorros
     * @param meses   Número de meses a proyectar
     */
    public void proyectarCrecimiento(CuentaAhorros cuenta, int meses) {
        if (meses <= 0 || meses > 360) {
            System.out.println("  Meses deben estar entre 1 y 360.");
            return;
        }

        System.out.printf("%n  ── Proyección a %d meses (tasa: %.2f%% mensual) ──%n",
                meses, cuenta.getTasaInteres() * 100);
        System.out.printf("  %-10s %-20s %-20s%n", "Mes", "Interés aplicado", "Saldo proyectado");
        System.out.println("  " + "─".repeat(52));

        double saldo = cuenta.getSaldo();
        for (int i = 1; i <= meses; i++) {
            double interes = saldo * cuenta.getTasaInteres();
            saldo += interes;
            if (i % Math.max(1, meses / 10) == 0 || i == meses) {
                System.out.printf("  %-10d $%-19,.2f $%-19,.2f%n", i, interes, saldo);
            }
        }
        System.out.println("  " + "─".repeat(52));
    }
}
