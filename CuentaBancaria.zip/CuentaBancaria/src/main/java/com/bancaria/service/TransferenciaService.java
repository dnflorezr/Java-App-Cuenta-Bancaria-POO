package com.bancaria.service;

import com.bancaria.exception.CuentaInvalidaException;
import com.bancaria.exception.MontoInvalidoException;
import com.bancaria.exception.SaldoInsuficienteException;
import com.bancaria.model.CuentaBancaria;
import com.bancaria.model.Transaccion;
import com.bancaria.model.TipoTransaccion;

/**
 * Servicio que gestiona transferencias entre cuentas bancarias.
 *
 * FUNCIONALIDAD 1: Transferencias entre cuentas
 *
 * Principio: Responsabilidad Única — solo gestiona la lógica de transferencia.
 * Principio: Inversión de Dependencias — opera sobre la interfaz IOperacionesBancarias.
 */
public class TransferenciaService {

    private static final double MONTO_MINIMO_TRANSFERENCIA = 1_000.0;
    private static final double MONTO_MAXIMO_TRANSFERENCIA = 50_000_000.0;

    /**
     * Realiza una transferencia entre dos cuentas de forma atómica.
     * Si algún paso falla, se lanza excepción y el estado no se modifica.
     *
     * @param origen   Cuenta que envía el dinero
     * @param destino  Cuenta que recibe el dinero
     * @param monto    Monto a transferir
     * @param nota     Descripción opcional de la transferencia
     */
    public void transferir(CuentaBancaria origen, CuentaBancaria destino,
                           double monto, String nota)
            throws MontoInvalidoException, SaldoInsuficienteException, CuentaInvalidaException {

        // ── Validaciones previas ──────────────────────────────────────────────
        validarCuentas(origen, destino);
        validarMontoTransferencia(monto);

        String descripcion = (nota != null && !nota.isBlank()) ? nota : "Transferencia";

        // ── Registro en cuenta origen ─────────────────────────────────────────
        double saldoOrigenAntes = origen.getSaldo();
        origen.retirar(monto); // Puede lanzar SaldoInsuficienteException

        // Si el retiro fue exitoso, procedemos con el crédito al destino
        double saldoDestinoAntes = destino.getSaldo();
        double saldoOrigenDespues = origen.getSaldo();

        // Registrar manualmente para usar TipoTransaccion específico
        // (reemplazamos el registro automático del retiro con uno más descriptivo)
        origen.getHistorial().registrar(new Transaccion(
                origen.getHistorial().generarId(),
                TipoTransaccion.TRANSFERENCIA_ENVIADA,
                monto,
                saldoOrigenAntes,
                saldoOrigenDespues,
                descripcion + " → " + destino.getNumeroCuenta(),
                origen.getNumeroCuenta(),
                destino.getNumeroCuenta()
        ));

        // ── Registro en cuenta destino ────────────────────────────────────────
        try {
            destino.depositar(monto);
        } catch (MontoInvalidoException e) {
            // Revertir el retiro de la cuenta origen si el depósito falla
            origen.depositar(monto);
            throw new CuentaInvalidaException("Error al acreditar en cuenta destino: " + e.getMessage());
        }

        destino.getHistorial().registrar(new Transaccion(
                destino.getHistorial().generarId(),
                TipoTransaccion.TRANSFERENCIA_RECIBIDA,
                monto,
                saldoDestinoAntes,
                destino.getSaldo(),
                descripcion + " ← " + origen.getNumeroCuenta(),
                origen.getNumeroCuenta(),
                destino.getNumeroCuenta()
        ));

        System.out.printf("%n  ✔ Transferencia exitosa: $%,.2f de [%s] a [%s]%n",
                monto, origen.getNumeroCuenta(), destino.getNumeroCuenta());
    }

    // ── Validaciones privadas ─────────────────────────────────────────────────

    private void validarCuentas(CuentaBancaria origen, CuentaBancaria destino)
            throws CuentaInvalidaException {
        if (origen == null)
            throw new CuentaInvalidaException("La cuenta origen no puede ser nula.");
        if (destino == null)
            throw new CuentaInvalidaException("La cuenta destino no puede ser nula.");
        if (origen.getNumeroCuenta().equals(destino.getNumeroCuenta()))
            throw new CuentaInvalidaException("No se puede transferir a la misma cuenta.");
    }

    private void validarMontoTransferencia(double monto) throws MontoInvalidoException {
        if (monto < MONTO_MINIMO_TRANSFERENCIA) {
            throw new MontoInvalidoException(monto,
                String.format("el monto mínimo de transferencia es $%,.0f", MONTO_MINIMO_TRANSFERENCIA));
        }
        if (monto > MONTO_MAXIMO_TRANSFERENCIA) {
            throw new MontoInvalidoException(monto,
                String.format("el monto máximo de transferencia es $%,.0f", MONTO_MAXIMO_TRANSFERENCIA));
        }
    }
}
