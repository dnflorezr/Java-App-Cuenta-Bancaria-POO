package com.bancaria.exception;

/**
 * Excepción lanzada cuando se opera sobre una cuenta inválida,
 * inexistente o con datos incorrectos.
 */
public class CuentaInvalidaException extends Exception {

    public CuentaInvalidaException(String mensaje) {
        super(mensaje);
    }

    public CuentaInvalidaException(String numeroCuenta, String razon) {
        super(String.format("Cuenta '%s' inválida: %s", numeroCuenta, razon));
    }
}
