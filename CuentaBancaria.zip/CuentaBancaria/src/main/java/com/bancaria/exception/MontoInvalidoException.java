package com.bancaria.exception;

/**
 * Excepción lanzada cuando el monto ingresado para una operación
 * es negativo, cero, o excede límites permitidos.
 */
public class MontoInvalidoException extends Exception {

    private final double montoIngresado;

    public MontoInvalidoException(double monto, String razon) {
        super(String.format("Monto inválido ($%,.2f): %s", monto, razon));
        this.montoIngresado = monto;
    }

    public double getMontoIngresado() { return montoIngresado; }
}
