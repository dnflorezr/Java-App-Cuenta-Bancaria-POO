package com.bancaria.exception;

/**
 * Excepción lanzada cuando el saldo de una cuenta es insuficiente
 * para completar una operación de retiro o transferencia.
 */
public class SaldoInsuficienteException extends Exception {

    private final double saldoActual;
    private final double montoSolicitado;

    public SaldoInsuficienteException(double saldoActual, double montoSolicitado) {
        super(String.format(
            "Saldo insuficiente. Disponible: $%,.2f | Solicitado: $%,.2f",
            saldoActual, montoSolicitado
        ));
        this.saldoActual = saldoActual;
        this.montoSolicitado = montoSolicitado;
    }

    public double getSaldoActual()     { return saldoActual; }
    public double getMontoSolicitado() { return montoSolicitado; }
}
